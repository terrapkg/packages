#include <iostream>

// this is c++ code, but the extension is .c,
// so clang doesn't change its behavior because of the extension

int main() {
    std::cout << "Hello, world!" << std::endl;
    return 0;
}
