#include <iostream>

void print_hello() {
    std::cout << "Hello, World!" << std::endl;
}
