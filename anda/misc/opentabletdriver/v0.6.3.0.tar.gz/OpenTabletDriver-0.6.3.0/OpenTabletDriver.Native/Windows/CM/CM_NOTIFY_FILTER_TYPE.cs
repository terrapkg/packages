namespace OpenTabletDriver.Native.Windows.CM
{
    public enum CM_NOTIFY_FILTER_TYPE
    {
        DEVICEINTERFACE = 0,
        DEVICEHANDLE,
        DEVICEINSTANCE,
        MAX
    }
}
