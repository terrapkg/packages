namespace OpenTabletDriver.Native.Windows.Display
{
    public enum MONITORINFOF : ulong
    {
        PRIMARY = 1
    }
}
