namespace OpenTabletDriver.Native.Windows
{
    public enum DpiType
    {
        Effective,
        Angular,
        Raw
    }
}
