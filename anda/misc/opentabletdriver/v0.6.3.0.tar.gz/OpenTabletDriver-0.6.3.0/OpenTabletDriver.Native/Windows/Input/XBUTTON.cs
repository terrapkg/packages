﻿namespace OpenTabletDriver.Native.Windows
{
    public enum XBUTTON : uint
    {
        NONE = 0x0000,
        XBUTTON1 = 0x0001,
        XBUTTON2 = 0x0002
    }
}
