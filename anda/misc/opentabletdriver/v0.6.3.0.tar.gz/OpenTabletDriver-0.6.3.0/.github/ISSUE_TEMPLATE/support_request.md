---
name: Support Request
about: Request help for something that isn't an obvious bug.
title: 'Support Request: '
labels: 'support request'
assignees: ''
---

# Support Request
<!-- What do you need help with? -->
<!-- Be descriptive and use images or video where possible. -->

## What I've already tried
<!-- Reference any wiki pages you've already tried -->

## Diagnostic Information
<!-- Export diagnostics and attach or paste below -->
<!-- In the GUI, click Help -> Export Diagnostics -->
