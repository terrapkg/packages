#!/bin/sh
set -eu -o pipefail

git init -q --bare
