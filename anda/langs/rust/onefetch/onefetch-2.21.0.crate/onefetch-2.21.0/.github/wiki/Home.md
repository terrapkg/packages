Welcome to the onefetch's wiki!

- **[Home](https://github.com/o2sh/onefetch/wiki)**
- **General**
  - [Installation](https://github.com/o2sh/onefetch/wiki/installation)
  - [Getting started](https://github.com/o2sh/onefetch/wiki/getting-started)
- **Options**
  - [Command-line options](https://github.com/o2sh/onefetch/wiki/command-line-options)
- **Images**
  - [Images in the terminal](https://github.com/o2sh/onefetch/wiki/Images-in-the-terminal)
- **Ascii**
  - [Ascii art](https://github.com/o2sh/onefetch/wiki/ascii-art)
