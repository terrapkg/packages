// Lib is present to allow for benchmarks and integration tests
pub mod cli;
pub mod info;
pub mod ui;
