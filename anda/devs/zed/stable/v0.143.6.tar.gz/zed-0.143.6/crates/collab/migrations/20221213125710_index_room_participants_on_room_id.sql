CREATE INDEX "index_room_participants_on_room_id" ON "room_participants" ("room_id");
