ALTER TABLE "worktree_entries"
    ADD COLUMN "scan_id" INT8,
    ADD COLUMN "is_deleted" BOOL;
