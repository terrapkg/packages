ALTER TABLE dev_servers ADD COLUMN ssh_connection_string TEXT;
