ALTER TABLE room_participants ADD COLUMN participant_index INTEGER;
