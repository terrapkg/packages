ALTER TABLE "signups"
    ADD "added_to_mailing_list" BOOLEAN NOT NULL DEFAULT FALSE;