ALTER TABLE access_tokens ADD COLUMN impersonated_user_id integer;
