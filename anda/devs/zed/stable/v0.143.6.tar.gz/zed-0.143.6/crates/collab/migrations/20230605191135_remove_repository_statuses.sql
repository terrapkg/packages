ALTER TABLE "worktree_entries"
ADD "git_status" INT8;
