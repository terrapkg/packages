CREATE UNIQUE INDEX "index_rooms_on_channel_id" ON "rooms" ("channel_id");
