ALTER TABLE room_participants ADD COLUMN role TEXT;
