ALTER TABLE rooms ADD COLUMN environment TEXT;
