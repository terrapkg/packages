ALTER TABLE "signups"
  ADD "wants_releases" BOOLEAN,
  ADD "wants_updates" BOOLEAN,
  ADD "wants_community" BOOLEAN;