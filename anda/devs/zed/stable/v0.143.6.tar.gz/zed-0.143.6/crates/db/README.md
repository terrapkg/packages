# Building Queries

First, craft your test data. The examples folder shows a template for building a test-db, and can be ran with `cargo run --example [your-example]`.

To actually use and test your queries, import the generated DB file into https://sqliteonline.com/
